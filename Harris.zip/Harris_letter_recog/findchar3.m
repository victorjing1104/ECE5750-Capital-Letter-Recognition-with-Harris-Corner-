function [score,tmp_s,s_list,new_loc,I, final_ans, tmp_list, comp]=findchar3(img_name,datastore,sig)
[new_loc,I, ~, ~, ~, ~, ~,elap,elap2] = harris2(img_name);
A = tic;
[row,col] = size(datastore);
tmp_s = cell(row,col);

for i = 1:col
    for j = 1:row
        new_loc2 = datastore{j,i};
        [r1,~] = size(new_loc);
        [r2,~] = size(new_loc2);
        len = min(r1,r2);
        tmp = new_loc;
        buffer = zeros(1,r1);
        comp = zeros(len,5);

        for k = 1:len
            [len2,~] = size(tmp);
            for z=1:len2
                dis = sqrt((new_loc2(k,1) - tmp(z,1))^2 + (new_loc2(k,2) - tmp(z,2))^2); 
                buffer(z) = dis;
            end
            [val,idx] = min(buffer);
            comp(k,:) = [tmp(idx,:),new_loc2(k,:),val];
            tmp(idx,:) =[];
            buffer(idx) = [];
        end
        [com_len,~] = size(comp);
        Dx = 0;
        Dy = 0;
        
        Dxx = 0;
        Dyy = 0;
        for t=1:com_len
            Dx = Dx + comp(t,1)/30*log(comp(t,1)/comp(t,3));
            Dy = Dy + comp(t,2)/30*log(comp(t,2)/comp(t,4));
            Dxx = Dxx + comp(t,3)/100*log(comp(t,3)/comp(t,1));
            Dyy = Dyy + comp(t,4)/100*log(comp(t,4)/comp(t,2));
        end
        x_pdf = mvnpdf(comp(:,1),comp(:,3),sig);
        y_pdf = mvnpdf(comp(:,2),comp(:,4),sig);
        tot_pdf = x_pdf.*y_pdf;
        tmp_s{j,i} = [sum(tot_pdf),sum(x_pdf)*sum(y_pdf), Dx*Dy];
    end
end

%compare
tmp_col = 3;
score = zeros(col,tmp_col);
for i=1:col
    score_tmp = zeros(row,tmp_col);
    for j=1:row
        score_tmp(j,:) = tmp_s{j,i}(1,1:tmp_col);
    end
    [~,M_idx] = max(score_tmp(:,1)); 
    score(i,1) = M_idx;
    [~,M_idx] = max(score_tmp(:,2));
    score(i,2) = M_idx;
    [~,M_idx] = min(abs(score_tmp(:,3)));
    score(i,3) = M_idx;
end

num_list = zeros(26,2);
for i=1:26
    num_list(i,1) = i;
    num_list(i,2) = sum(score(:,1) == i);
end
[val,idx] = max(num_list(:,2));

num_list2 = zeros(26,2);
for i=1:26
    num_list2(i,1) = i;
    num_list2(i,2) = sum(score(:,2) == i);
end
[val2,idx2] = max(num_list2(:,2));

num_list3 = zeros(26,2);
for i=1:26
    num_list3(i,1) = i;
    num_list3(i,2) = sum(score(:,3) == i);
end
[val3,idx3] = max(num_list3(:,2));

Text_arr =['A','B','C','D','E','F','G','H','I','J','K','L','M','N','O','P',...
    'Q','R','S','T','U','V','W','X','Y','Z'];
%answer
tmp_list = [idx, idx2, idx3];
s_list = [num_list,num_list2, num_list3];
if(idx == idx2 || idx == idx3)
    final_ans = Text_arr(idx);
elseif(idx2 == idx3)
    final_ans = Text_arr(idx2);
else
    tmp_val = [val, val2, val3];
    [max_val,val_idx] = max(tmp_val);
    [~,val_len] = find(tmp_val == max_val);
    if(length(val_len) == 2)
        if(val_len(1) == 1 && val_len(2) == 3)
            final_ans = Text_arr(idx); %try
        else
            final_ans = Text_arr(idx2); %try
        end
    else
        final_ans = Text_arr(tmp_list(val_idx));  
    end
end

%disp([Text_arr(idx), num2str(val),Text_arr(idx2),num2str(val2),Text_arr(idx3),num2str(val3), final_ans]);
T2 = toc(A) + elap2;
p = ['Harris corner computation time:', num2str(elap)];
disp(p);
p2 = ['Total computation time:', num2str(T2)];
disp(p2);
end