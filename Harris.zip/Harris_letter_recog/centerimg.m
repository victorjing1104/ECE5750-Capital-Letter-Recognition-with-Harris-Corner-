function [final_img] = centerimg(img)
loc_x =zeros(1,0);
[row,col] = size(img);
for j = 1:col % X direction
    obs = find(img(:,j)==1, 1);
    if(~isempty(obs))
        loc_x = [loc_x,j];
    end
end
loc_y =zeros(1,0);
for j = 1:row % X direction
    obs = find(img(j,:)==1, 1);
    if(~isempty(obs))
        loc_y = [loc_y,j];
    end
end
xm = min(loc_x);
ym = min(loc_y);
xM = max(loc_x);
yM = max(loc_y);
new_img = zeros(yM-ym+1,xM-xm+1);
for i=1:xM-xm+1
    for j=1:yM-ym+1
        new_img(j,i) = img(ym+j-1,xm+i-1);
    end
end

[n_row,n_col] = size(new_img);
dim = max(n_row,n_col);
if(rem(dim,2) ==1)
    dim = dim + 19;
else
    dim = dim + 20;
end

final_img = zeros(dim,dim);

if(rem(n_row,2) ==1)
    init_x = (dim - n_row + 1)/2;
else
    init_x = (dim - n_row)/2;
end
if(rem(n_col,2) ==1)
    init_y = (dim - n_col + 1)/2;
else
    init_y = (dim - n_col)/2;
end


for i = 1:n_row
    for j = 1:n_col
        final_img(i+init_x,j+init_y) = new_img(i,j);
    end
end

final_img = imbinarize(final_img,'global');
end






