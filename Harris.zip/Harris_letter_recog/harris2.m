function [data_loc, im, stor_r, tmp_R, I, result,elap,elap2] = harris2(img_name)
k = 0.04;
Threshold = 0.1;
sigma = 1;
halfwid = sigma;
[xx, yy] = meshgrid(-halfwid:halfwid, -halfwid:halfwid);
Gxy = exp(-(xx .^ 2 + yy .^ 2) / (2 * sigma ^ 2));
Gx = xx .* exp(-(xx .^ 2 + yy .^ 2) / (2 * sigma ^ 2));
Gy = yy .* exp(-(xx .^ 2 + yy .^ 2) / (2 * sigma ^ 2));

I_struct=importdata(img_name); %import image
if(size(I_struct.cdata,3)==3) %check if it is a color image
    I_gray = rgb2gray(I_struct.cdata);
else
    I_gray = I_struct.alpha;
end
% I = imread(img_name);
% I = rgb2gray(I);
% BW = double(I)/255;
BW = imbinarize(I_gray,'global'); %covert gray image to binaray image
[~,dis] = size(BW);
if(length(find(BW(1,:)==1)) >= (dis/2)) %%reverse pattern
    BW = ~BW;
end
CM = centerimg(BW); 
I = imresize(CM,[30,30]);
ha = tic;
numOfRows = size(I, 1);
numOfColumns = size(I, 2);

% 1) Compute x and y derivatives of image
Ix1 = conv2(Gx, I);
Iy = conv2(Gy, I);

% reduce size to original
Ix = Ix1(2:numOfColumns+1, 2:numOfColumns+1);
Iy = Iy(2:numOfColumns+1, 2:numOfColumns+1);

% 2) Compute products of derivatives at every pixel
Ix2 = Ix .^ 2;
Iy2 = Iy .^ 2;
Ixy = Ix .* Iy;

% 3)Compute the sums of the products of derivatives at each pixel
Sx2 = conv2(Gxy, Ix2);
Sy2 = conv2(Gxy, Iy2);
Sxy = conv2(Gxy, Ixy);

% reduce size
Sx2 = Sx2(2:numOfColumns+1, 2:numOfColumns+1);
Sy2 = Sy2(2:numOfColumns+1, 2:numOfColumns+1);
Sxy = Sxy(2:numOfColumns+1, 2:numOfColumns+1);

stor_r = zeros(numOfRows, numOfColumns);
im = zeros(numOfRows, numOfColumns);
for x=1:numOfRows
   for y=1:numOfColumns
       % 4) Define at each pixel(x, y) the matrix H
       H = [Sx2(x, y) Sxy(x, y); Sxy(x, y) Sy2(x, y)];
       
       % 5) Compute the response of the detector at each pixel
       R = det(H) - k * (trace(H) ^ 2);
       stor_r(x,y) = R;
       % 6) Threshold on value of R
       if (R > Threshold)
          im(x, y) = R ; 
       end
   end
end
elap = toc(ha);

tmp_R = im;
len=length(im);
for i = 1:len-2
    for j = 1:len-2
        buff = tmp_R(i:i+2,j:j+2);
        [~, M_idx] = max(buff(:));
        for k= 1:9
           if(k ~= M_idx)
               buff(k) = 0; 
           end
        end
        tmp_R(i:i+2,j:j+2) = buff;
    end
end

o_idx = 1;
for i=1:len
    for j=1:len
        if(tmp_R(i,j) ~=0)
            result(o_idx,:) = [i,j,tmp_R(i,j)];
            o_idx = o_idx + 1;
        end
    end
end
[~,r_idx]=sort(result(:,3),'descend');
data_loc = result(r_idx,1:2);
elap2 = toc(ha);

end